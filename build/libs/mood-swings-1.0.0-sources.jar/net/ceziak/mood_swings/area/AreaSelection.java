package net.ceziak.mood_swings.area;

import net.minecraft.class_2338;

public final class AreaSelection {
    private class_2338 first;
    private class_2338 second;
    private String firstDimension;
    private String secondDimension;

    public class_2338 first() {
        return first;
    }

    public class_2338 second() {
        return second;
    }

    public String dimension() {
        return firstDimension;
    }

    public void setFirst(class_2338 first, String dimension) {
        this.first = first.method_10062();
        this.firstDimension = dimension;
        if (this.second != null && !dimension.equals(this.secondDimension)) {
            this.second = null;
            this.secondDimension = null;
        }
    }

    public void setSecond(class_2338 second, String dimension) {
        this.second = second.method_10062();
        this.secondDimension = dimension;
        if (this.first != null && !dimension.equals(this.firstDimension)) {
            this.first = null;
            this.firstDimension = null;
        }
    }

    public boolean isComplete() {
        return first != null
                && second != null
                && firstDimension != null
                && firstDimension.equals(secondDimension);
    }
}
