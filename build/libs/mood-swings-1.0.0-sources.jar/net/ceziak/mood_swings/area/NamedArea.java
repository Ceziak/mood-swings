package net.ceziak.mood_swings.area;

import net.minecraft.class_2338;
import net.minecraft.class_3222;

public record NamedArea(
        String dimension,
        int minX,
        int minY,
        int minZ,
        int maxX,
        int maxY,
        int maxZ,
        String displayName
) {
    public static NamedArea between(String dimension, class_2338 first, class_2338 second, String displayName) {
        return new NamedArea(
                dimension,
                Math.min(first.method_10263(), second.method_10263()),
                Math.min(first.method_10264(), second.method_10264()),
                Math.min(first.method_10260(), second.method_10260()),
                Math.max(first.method_10263(), second.method_10263()),
                Math.max(first.method_10264(), second.method_10264()),
                Math.max(first.method_10260(), second.method_10260()),
                displayName
        );
    }

    public boolean contains(class_3222 player) {
        if (!dimension.equals(player.method_37908().method_27983().method_29177().toString())) {
            return false;
        }

        class_2338 pos = player.method_24515();
        return pos.method_10263() >= minX && pos.method_10263() <= maxX
                && pos.method_10264() >= minY && pos.method_10264() <= maxY
                && pos.method_10260() >= minZ && pos.method_10260() <= maxZ;
    }

    public String cornersString() {
        return "(" + minX + ", " + minY + ", " + minZ + ") -> ("
                + maxX + ", " + maxY + ", " + maxZ + ")";
    }
}
