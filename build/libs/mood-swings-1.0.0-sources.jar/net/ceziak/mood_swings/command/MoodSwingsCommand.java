package net.ceziak.mood_swings.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import dev.doctor4t.wathe.cca.PlayerMoodComponent;
import net.ceziak.mood_swings.access.PlayerMoodComponentAccess;
import net.ceziak.mood_swings.area.AreaSelection;
import net.ceziak.mood_swings.area.AreaStore;
import net.ceziak.mood_swings.area.NamedArea;
import net.ceziak.mood_swings.config.MoodSwingsConfigManager;
import net.ceziak.mood_swings.config.WorldDataStore;
import net.ceziak.mood_swings.task.CustomTaskConditions;
import net.ceziak.mood_swings.task.CustomTaskType;
import net.ceziak.mood_swings.task.CustomTrainTask;
import net.ceziak.mood_swings.task.TaskRegistry;
import net.minecraft.class_124;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2172;
import net.minecraft.class_2262;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

public final class MoodSwingsCommand {
    private static final Map<UUID, AreaSelection> SELECTIONS = new HashMap<>();

    private MoodSwingsCommand() {
    }

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(class_2170.method_9247("moodswings")
                .requires(source -> source.method_9259(2))
                .then(class_2170.method_9247("area")
                        .then(class_2170.method_9247("pos1")
                                .executes(context -> setSelectionPosition(
                                        context.getSource(),
                                        true,
                                        context.getSource().method_9207().method_24515()
                                ))
                                .then(class_2170.method_9244("pos", class_2262.method_9698())
                                        .executes(context -> setSelectionPosition(
                                                context.getSource(),
                                                true,
                                                class_2262.method_48299(context, "pos")
                                        )))
                        )
                        .then(class_2170.method_9247("pos2")
                                .executes(context -> setSelectionPosition(
                                        context.getSource(),
                                        false,
                                        context.getSource().method_9207().method_24515()
                                ))
                                .then(class_2170.method_9244("pos", class_2262.method_9698())
                                        .executes(context -> setSelectionPosition(
                                                context.getSource(),
                                                false,
                                                class_2262.method_48299(context, "pos")
                                        )))
                        )
                        .then(class_2170.method_9247("save")
                                .then(class_2170.method_9244("name", StringArgumentType.string())
                                        .executes(context -> saveArea(
                                                context.getSource(),
                                                StringArgumentType.getString(context, "name")
                                        )))
                        )
                        .then(class_2170.method_9247("remove")
                                .then(class_2170.method_9244("name", StringArgumentType.string())
                                        .suggests((context, builder) -> class_2172.method_9265(AreaStore.all().keySet(), builder))
                                        .executes(context -> removeArea(
                                                context.getSource(),
                                                StringArgumentType.getString(context, "name")
                                        )))
                        )
                        .then(class_2170.method_9247("info")
                                .then(class_2170.method_9244("name", StringArgumentType.string())
                                        .suggests((context, builder) -> class_2172.method_9265(AreaStore.all().keySet(), builder))
                                        .executes(context -> showAreaInfo(
                                                context.getSource(),
                                                StringArgumentType.getString(context, "name")
                                        )))
                        )
                        .then(class_2170.method_9247("show")
                                .then(class_2170.method_9244("name", StringArgumentType.string())
                                        .suggests((context, builder) -> class_2172.method_9265(AreaStore.all().keySet(), builder))
                                        .executes(context -> showAreaParticles(
                                                context.getSource(),
                                                StringArgumentType.getString(context, "name")
                                        )))
                        )
                        .then(class_2170.method_9247("list")
                                .executes(context -> listAreas(context.getSource())))
                )
                .then(class_2170.method_9247("task")
                        .then(class_2170.method_9247("force")
                                .then(class_2170.method_9244("task", StringArgumentType.word())
                                        .suggests((context, builder) -> class_2172.method_9265(TaskRegistry.CUSTOM_IDS, builder))
                                        .executes(context -> forceTask(
                                                context.getSource(),
                                                StringArgumentType.getString(context, "task")
                                        )))
                        )
                        .then(class_2170.method_9247("clear")
                                .executes(context -> clearTask(context.getSource())))
                        .then(class_2170.method_9247("disable")
                                .then(class_2170.method_9244("task", StringArgumentType.word())
                                        .suggests((context, builder) -> class_2172.method_9265(TaskRegistry.ALL_IDS, builder))
                                        .executes(context -> setTaskEnabled(
                                                context.getSource(),
                                                StringArgumentType.getString(context, "task"),
                                                false
                                        )))
                        )
                        .then(class_2170.method_9247("enable")
                                .then(class_2170.method_9244("task", StringArgumentType.word())
                                        .suggests((context, builder) -> class_2172.method_9265(TaskRegistry.ALL_IDS, builder))
                                        .executes(context -> setTaskEnabled(
                                                context.getSource(),
                                                StringArgumentType.getString(context, "task"),
                                                true
                                        )))
                        )
                        .then(class_2170.method_9247("list")
                                .executes(context -> listTaskSettings(context.getSource())))
                )
                .then(class_2170.method_9247("reload")
                        .executes(context -> reloadConfig(context.getSource())))
        );
    }

    private static int setSelectionPosition(class_2168 source, boolean first, class_2338 position)
            throws CommandSyntaxException {
        class_3222 player = source.method_9207();
        AreaSelection selection = SELECTIONS.computeIfAbsent(player.method_5667(), ignored -> new AreaSelection());

        String dimension = player.method_37908().method_27983().method_29177().toString();
        if (first) {
            selection.setFirst(position, dimension);
        } else {
            selection.setSecond(position, dimension);
        }

        source.method_9226(
                () -> class_2561.method_43470((first ? "Area position 1" : "Area position 2") + " set to " + position.method_23854()),
                false
        );
        return 1;
    }

    private static int saveArea(class_2168 source, String name) throws CommandSyntaxException {
        class_3222 player = source.method_9207();
        AreaSelection selection = SELECTIONS.get(player.method_5667());

        if (name.isBlank()) {
            source.method_9213(class_2561.method_43470("The area name cannot be empty."));
            return 0;
        }
        if (selection == null || !selection.isComplete()) {
            source.method_9213(class_2561.method_43470("Set both corners first with /moodswings area pos1 and pos2."));
            return 0;
        }

        NamedArea area = NamedArea.between(
                selection.dimension(),
                selection.first(),
                selection.second(),
                name.trim()
        );
        AreaStore.put(name, area);
        source.method_9226(() -> class_2561.method_43470("Saved area '" + name + "': " + area.cornersString()), true);
        return 1;
    }

    private static int removeArea(class_2168 source, String name) {
        String normalized = WorldDataStore.normalize(name);
        if (!AreaStore.remove(name)) {
            source.method_9213(class_2561.method_43470("No named area called '" + name + "'."));
            return 0;
        }

        removeTasksUsingArea(source, normalized);
        source.method_9226(() -> class_2561.method_43470("Removed area '" + name + "'."), true);
        return 1;
    }

    private static int showAreaInfo(class_2168 source, String name) {
        NamedArea area = AreaStore.get(name).orElse(null);
        if (area == null) {
            source.method_9213(class_2561.method_43470("No named area called '" + name + "'."));
            return 0;
        }

        source.method_9226(() -> class_2561.method_43470(
                "Area '" + areaDisplayName(name, area) + "' in " + area.dimension() + ": " + area.cornersString()
        ), false);
        return 1;
    }

    private static int listAreas(class_2168 source) {
        if (AreaStore.all().isEmpty()) {
            source.method_9226(() -> class_2561.method_43470("No named areas have been saved yet."), false);
            return 1;
        }

        source.method_9226(() -> class_2561.method_43470("Named Mood Swings areas in this save:"), false);
        AreaStore.all().forEach((name, area) -> source.method_9226(
                () -> class_2561.method_43470("• " + areaDisplayName(name, area) + " [" + name + "]  " + area.cornersString()),
                false
        ));
        return AreaStore.all().size();
    }

    private static int showAreaParticles(class_2168 source, String name) {
        NamedArea area = AreaStore.get(name).orElse(null);
        if (area == null) {
            source.method_9213(class_2561.method_43470("No named area called '" + name + "'."));
            return 0;
        }

        class_3218 world = source.method_9225();
        if (!world.method_27983().method_29177().toString().equals(area.dimension())) {
            source.method_9213(class_2561.method_43470("That area is in dimension " + area.dimension() + "."));
            return 0;
        }

        int[] xs = {area.minX(), area.maxX()};
        int[] ys = {area.minY(), area.maxY()};
        int[] zs = {area.minZ(), area.maxZ()};
        for (int x : xs) {
            for (int y : ys) {
                for (int z : zs) {
                    world.method_14199(class_2398.field_11207, x + 0.5D, y + 0.5D, z + 0.5D,
                            12, 0.15D, 0.15D, 0.15D, 0.01D);
                }
            }
        }

        source.method_9226(() -> class_2561.method_43470("Outlined the eight corners of area '" + name + "'."), false);
        return 1;
    }

    private static int forceTask(class_2168 source, String taskId) throws CommandSyntaxException {
        class_3222 player = source.method_9207();
        CustomTaskType type = CustomTaskType.byId(taskId).orElse(null);
        if (type == null) {
            source.method_9213(class_2561.method_43470("Unknown custom task '" + taskId + "'."));
            return 0;
        }
        if (!WorldDataStore.isTaskEnabled(type.id())) {
            source.method_9213(class_2561.method_43470("Task '" + type.id() + "' is disabled in this save."));
            return 0;
        }
        if (!CustomTaskConditions.isTaskAvailable(player, type)) {
            source.method_9213(class_2561.method_43470("Task '" + type.id() + "' is missing a required named area."));
            return 0;
        }

        PlayerMoodComponent component = PlayerMoodComponent.KEY.get(player);
        component.tasks.clear();
        PlayerMoodComponent.Task storage = CustomTrainTask.chooseStorageType(component.timesGotten);
        CustomTrainTask task = CustomTrainTask.create(player, type, storage, true);
        if (task == null) {
            source.method_9213(class_2561.method_43470("No valid target could be selected for that task."));
            return 0;
        }

        component.tasks.put(storage, task);
        ((PlayerMoodComponentAccess) component).moodSwings$setNextTaskTimer(2);
        component.sync();

        source.method_9226(() -> class_2561.method_43470("Forced task '" + type.id() + "' for " + player.method_5477().getString() + "."), false);
        return 1;
    }

    private static int clearTask(class_2168 source) throws CommandSyntaxException {
        class_3222 player = source.method_9207();
        PlayerMoodComponent component = PlayerMoodComponent.KEY.get(player);
        component.tasks.clear();
        ((PlayerMoodComponentAccess) component).moodSwings$setNextTaskTimer(2);
        component.sync();
        source.method_9226(() -> class_2561.method_43470("Cleared your mood task. Normal rotation will resume."), false);
        return 1;
    }

    private static int setTaskEnabled(class_2168 source, String taskId, boolean enabled) {
        String normalized = taskId.trim().toLowerCase(Locale.ROOT);
        if (!TaskRegistry.isKnown(normalized)) {
            source.method_9213(class_2561.method_43470("Unknown task '" + taskId + "'."));
            return 0;
        }

        boolean changed = enabled
                ? WorldDataStore.enableTask(normalized)
                : WorldDataStore.disableTask(normalized);

        if (!enabled) {
            removeTaskFromOnlinePlayers(source, normalized);
        }

        source.method_9226(
                () -> class_2561.method_43470("Task '" + normalized + "' is now " + (enabled ? "enabled" : "disabled") + " in this save."),
                true
        );
        return changed ? 1 : 0;
    }

    private static int listTaskSettings(class_2168 source) {
        source.method_9226(() -> class_2561.method_43470("Mood tasks for this save:"), false);
        for (String taskId : TaskRegistry.ALL_IDS) {
            boolean enabled = WorldDataStore.isTaskEnabled(taskId);
            class_124 color = enabled ? class_124.field_1060 : class_124.field_1061;
            source.method_9226(
                    () -> class_2561.method_43470("• " + taskId + ": " + (enabled ? "ENABLED" : "DISABLED")).method_27692(color),
                    false
            );
        }
        return TaskRegistry.ALL_IDS.size();
    }

    private static int reloadConfig(class_2168 source) {
        MoodSwingsConfigManager.reload();
        removeUnavailableTasksFromOnlinePlayers(source);
        source.method_9226(() -> class_2561.method_43470("Reloaded config/mood_swings.json."), true);
        return 1;
    }

    private static void removeTaskFromOnlinePlayers(class_2168 source, String taskId) {
        for (class_3222 player : source.method_9211().method_3760().method_14571()) {
            PlayerMoodComponent component = PlayerMoodComponent.KEY.get(player);
            boolean removed = component.tasks.entrySet().removeIf(entry -> TaskRegistry.idOf(entry.getValue()).equals(taskId));
            if (removed) {
                ((PlayerMoodComponentAccess) component).moodSwings$setNextTaskTimer(2);
                component.sync();
            }
        }
    }

    private static void removeTasksUsingArea(class_2168 source, String removedAreaId) {
        String gymArea = WorldDataStore.normalize(MoodSwingsConfigManager.get().safeGymAreaId());
        String rooftopArea = WorldDataStore.normalize(MoodSwingsConfigManager.get().safeRooftopAreaId());

        for (class_3222 player : source.method_9211().method_3760().method_14571()) {
            PlayerMoodComponent component = PlayerMoodComponent.KEY.get(player);
            boolean removed = component.tasks.entrySet().removeIf(entry -> {
                if (!(entry.getValue() instanceof CustomTrainTask custom)) {
                    return false;
                }
                return switch (custom.customType()) {
                    case STRANGE_NOISE -> removedAreaId.equals(WorldDataStore.normalize(custom.targetAreaId()));
                    case GYM -> removedAreaId.equals(gymArea);
                    case ROOFTOP -> removedAreaId.equals(rooftopArea);
                    default -> false;
                };
            });
            if (removed) {
                ((PlayerMoodComponentAccess) component).moodSwings$setNextTaskTimer(2);
                component.sync();
            }
        }
    }

    private static void removeUnavailableTasksFromOnlinePlayers(class_2168 source) {
        for (class_3222 player : source.method_9211().method_3760().method_14571()) {
            PlayerMoodComponent component = PlayerMoodComponent.KEY.get(player);
            boolean removed = component.tasks.entrySet().removeIf(entry ->
                    entry.getValue() instanceof CustomTrainTask custom
                            && !CustomTaskConditions.isTaskAvailable(player, custom.customType())
            );
            if (removed) {
                ((PlayerMoodComponentAccess) component).moodSwings$setNextTaskTimer(2);
                component.sync();
            }
        }
    }

    private static String areaDisplayName(String key, NamedArea area) {
        if (area.displayName() != null && !area.displayName().isBlank()) {
            return area.displayName();
        }
        return key;
    }
}
