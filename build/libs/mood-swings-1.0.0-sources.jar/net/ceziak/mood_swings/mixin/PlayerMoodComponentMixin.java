package net.ceziak.mood_swings.mixin;

import dev.doctor4t.wathe.cca.PlayerMoodComponent;
import net.ceziak.mood_swings.access.PlayerMoodComponentAccess;
import net.ceziak.mood_swings.task.CustomTaskRoller;
import net.ceziak.mood_swings.task.CustomTrainTask;
import net.ceziak.mood_swings.task.TaskRegistry;
import net.minecraft.class_1657;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_3222;
import net.minecraft.class_7225;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Map;

@Mixin(PlayerMoodComponent.class)
public abstract class PlayerMoodComponentMixin implements PlayerMoodComponentAccess {
    @Shadow
    @Final
    private class_1657 player;

    @Shadow
    @Final
    public Map<PlayerMoodComponent.Task, PlayerMoodComponent.TrainTask> tasks;

    @Shadow
    @Final
    public Map<PlayerMoodComponent.Task, Integer> timesGotten;

    @Shadow
    private int nextTaskTimer;

    @Unique
    private boolean moodSwings$customTaskWasActive;

    @Override
    public void moodSwings$setNextTaskTimer(int ticks) {
        this.nextTaskTimer = Math.max(0, ticks);
    }

    @Inject(method = "serverTick", at = @At("HEAD"))
    private void moodSwings$rememberCustomTask(CallbackInfo callback) {
        this.moodSwings$customTaskWasActive = this.tasks.values().stream()
                .anyMatch(CustomTrainTask.class::isInstance);
    }

    @Inject(method = "serverTick", at = @At("RETURN"))
    private void moodSwings$resumeRotationAfterCustomTask(CallbackInfo callback) {
        if (this.moodSwings$customTaskWasActive && this.tasks.isEmpty()) {
            this.nextTaskTimer = 2;
        }
        this.moodSwings$customTaskWasActive = false;
    }

    @Inject(method = "generateTask", at = @At("HEAD"), cancellable = true)
    private void moodSwings$rollCustomTask(
            CallbackInfoReturnable<PlayerMoodComponent.TrainTask> callback
    ) {
        if (!(player instanceof class_3222 serverPlayer) || !tasks.isEmpty()) {
            return;
        }

        CustomTrainTask customTask = CustomTaskRoller.tryRoll(serverPlayer, timesGotten);
        if (customTask != null) {
            callback.setReturnValue(customTask);
        }
    }

    @Redirect(
            method = "generateTask",
            at = @At(
                    value = "INVOKE",
                    target = "Ldev/doctor4t/wathe/cca/PlayerMoodComponent$Task;values()[Ldev/doctor4t/wathe/cca/PlayerMoodComponent$Task;"
            )
    )
    private PlayerMoodComponent.Task[] moodSwings$filterNativeTasks() {
        return TaskRegistry.enabledNativeTasks();
    }

    @Inject(method = "readFromNbt", at = @At("TAIL"))
    private void moodSwings$restoreCustomTasks(
            class_2487 tag,
            class_7225.class_7874 registryLookup,
            CallbackInfo callback
    ) {
        if (!tag.method_10573("tasks", class_2520.field_33259)) {
            return;
        }

        class_2499 taskList = tag.method_10554("tasks", class_2520.field_33260);
        for (class_2520 element : taskList) {
            if (!(element instanceof class_2487 compound) || !compound.method_10545(CustomTrainTask.NBT_CUSTOM_ID)) {
                continue;
            }

            CustomTrainTask customTask = CustomTrainTask.fromNbt(compound);
            if (customTask != null) {
                tasks.put(customTask.getType(), customTask);
            }
        }
    }
}
