package net.ceziak.mood_swings.task;

import dev.doctor4t.wathe.block.SprinklerBlock;
import net.ceziak.mood_swings.area.AreaStore;
import net.ceziak.mood_swings.config.MoodSwingsConfig;
import net.ceziak.mood_swings.config.MoodSwingsConfigManager;
import net.minecraft.class_1657;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_3222;

public final class CustomTaskConditions {
    private CustomTaskConditions() {
    }

    public static boolean isDurationConditionMet(class_3222 player, CustomTrainTask task) {
        return switch (task.customType()) {
            case TAKE_A_SHOWER -> isUnderActiveShower(player);
            case SOCIALIZE -> isNearAnotherPlayer(player);
            case GYM -> isInsideConfiguredArea(player, MoodSwingsConfigManager.get().safeGymAreaId());
            case STRANGE_NOISE -> task.targetAreaId() != null && isInsideConfiguredArea(player, task.targetAreaId());
            case ROOFTOP -> isInsideConfiguredArea(player, MoodSwingsConfigManager.get().safeRooftopAreaId());
            case WALK -> false;
        };
    }

    public static int requiredTicks(CustomTaskType type) {
        MoodSwingsConfig config = MoodSwingsConfigManager.get();
        return switch (type) {
            case TAKE_A_SHOWER -> config.showerDurationTicks();
            case SOCIALIZE -> config.socializeDurationTicks();
            case GYM -> config.gymDurationTicks();
            case STRANGE_NOISE -> config.strangeNoiseDurationTicks();
            case ROOFTOP -> config.rooftopDurationTicks();
            case WALK -> 0;
        };
    }

    public static boolean isTaskAvailable(class_3222 player, CustomTaskType type) {
        MoodSwingsConfig config = MoodSwingsConfigManager.get();
        return switch (type) {
            case GYM -> isAreaAvailableForPlayer(player, config.safeGymAreaId());
            case ROOFTOP -> isAreaAvailableForPlayer(player, config.safeRooftopAreaId());
            case STRANGE_NOISE -> !AreaStore.inPlayerDimension(player).isEmpty();
            default -> true;
        };
    }

    private static boolean isInsideConfiguredArea(class_3222 player, String areaId) {
        return AreaStore.get(areaId).map(area -> area.contains(player)).orElse(false);
    }

    private static boolean isAreaAvailableForPlayer(class_3222 player, String areaId) {
        String dimension = player.method_37908().method_27983().method_29177().toString();
        return AreaStore.get(areaId)
                .filter(area -> dimension.equals(area.dimension()))
                .isPresent();
    }

    private static boolean isUnderActiveShower(class_3222 player) {
        MoodSwingsConfig config = MoodSwingsConfigManager.get();
        class_2338 playerPos = player.method_24515();
        class_2338.class_2339 checkPos = new class_2338.class_2339();

        for (int offsetY = 1; offsetY <= config.safeShowerScanHeight(); offsetY++) {
            checkPos.method_10103(playerPos.method_10263(), playerPos.method_10264() + offsetY, playerPos.method_10260());
            class_2680 state = player.method_37908().method_8320(checkPos);
            if (!state.method_26164(MoodSwingsTags.SHOWER_HEADS)) {
                continue;
            }

            if (state.method_26204() instanceof SprinklerBlock) {
                if (state.method_11654(SprinklerBlock.POWERED)
                        && SprinklerBlock.method_10119(state) == class_2350.field_11033) {
                    return true;
                }
                continue;
            }

            if (state.method_28498(class_2741.field_12484) && !state.method_11654(class_2741.field_12484)) {
                continue;
            }
            if (state.method_28498(class_2741.field_12525) && state.method_11654(class_2741.field_12525) != class_2350.field_11033) {
                continue;
            }
            return true;
        }

        return false;
    }

    private static boolean isNearAnotherPlayer(class_3222 player) {
        double range = MoodSwingsConfigManager.get().safeSocializeRange();
        double rangeSquared = range * range;

        for (class_1657 other : player.method_37908().method_18456()) {
            if (other == player || other.method_7325() || !other.method_5805()) {
                continue;
            }
            if (player.method_5858(other) <= rangeSquared) {
                return true;
            }
        }
        return false;
    }
}
