package net.ceziak.mood_swings.task;

import net.ceziak.mood_swings.MoodSwings;
import net.minecraft.class_2248;
import net.minecraft.class_6862;
import net.minecraft.class_7924;

public final class MoodSwingsTags {
    public static final class_6862<class_2248> SHOWER_HEADS = class_6862.method_40092(
            class_7924.field_41254,
            MoodSwings.id("shower_heads")
    );

    private MoodSwingsTags() {
    }
}
